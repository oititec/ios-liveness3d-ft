//
//  FaceTecSDK.h
//  FaceTecSDK
//
//  Copyright © 2020 FaceTec. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FaceTecSDK.
FOUNDATION_EXPORT double FaceTecSDKVersionNumber;

//! Project version string for FaceTecSDK.
FOUNDATION_EXPORT const unsigned char FaceTecSDKVersionString[];

#import "FaceTecPublicApi.h"
